import {createStore, combineReducers, applyMiddleware} from "redux"
import thunk from 'redux-thunk';
import appReducer from "./reducers/appReducer";
import userReducer from "./reducers/userReducer";

let rootReducer = combineReducers({
    app: appReducer,
    user: userReducer
})
let store = createStore(rootReducer, applyMiddleware(thunk))

export default store;

