import UserAPI from "../../API/UserAPI.js"
import {actions as appActions} from "../reducers/appReducer"
import {thunks as appThunks} from "./appReducer"

let initState = {
    user: null,
    users: [],
    registrationError: null,
    authorizationError: null,
    profileUser: null,
    getUserError: null,
    friends: [],
    messages: [],
    messageUser: null,
    isFriends: null,
    amountOfUnreadMessages: null,
    messagesPageInfo: null,
    userMessages: []
}

const userReducer = (state = initState, action) => {
    switch (action.type) {
        case "USER/SET_REGISTRATION_ERROR":
            return {
                ...state,
                registrationError: action.value
            }
        break;
        case "USER/SET_AMOUNT_OF_UNREAD_MESSAGES":
            return {
                ...state,
                amountOfUnreadMessages: action.value
            }
            break;
        case "USER/SET_IS_FRIENDS":
            return {
                ...state,
                isFriends: action.value
            }
        break;
        case "USER/SET_AUTHORIZATION_ERROR":
            return {
                ...state,
                authorizationError: action.value
            }
        break;
        case "USER/SET_PROFILE_USER":
            return {
                ...state,
                profileUser: JSON.parse(JSON.stringify(action.user))
            }
        break;
        case "USER/SET_GET_USER_ERROR":
            return {
                ...state,
                getUserError: action.error
            }
        break;
        case "USER/SET_FRIENDS":
            return {
                ...state,
                friends: [...action.friends]
            }
        break;
        case "USER/SET_MESSAGES":
            return {
                ...state,
                messages: [...action.messages],
                messageUser: {...action.messageUser}
            }
        break;
        case "USER/SET_MESSAGES_PAGE_INFO":
            return {
                ...state,
                messagesPageInfo: action.info
            }
        break;
        case "USER/SET_USERS":
            return {
                ...state,
                users: action.users
            }
            break;
        default: 
            return state;
    }
}

export const actions = {
    setRegistrationError: (value) => ({
        type: "USER/SET_REGISTRATION_ERROR",
        value: value
    }),
    setProfileUser: (value) => ({
        type: "USER/SET_PROFILE_USER",
        user: value
    }),
    setAuthorizationError: (value) => ({
        type: "USER/SET_AUTHORIZATION_ERROR",
        value: value
    }),
    setGetUserError: (value) => ({
        type: "USER/SET_GET_USER_ERROR",
        error: value
    }),
    setFriends: (friends) => ({
        type: "USER/SET_FRIENDS",
        friends
    }),
    setIsFriends: (value) => ({
        type: "USER/SET_IS_FRIENDS",
        value
    }),
    setMessages: (messages, messageUser) => ({
        type: "USER/SET_MESSAGES",
        messages,
        messageUser
    }),
    setAmountOfUnreadMessages: (value) => ({
        type: "USER/SET_AMOUNT_OF_UNREAD_MESSAGES",
        value
    }),
    setMessagesPageInfo: (info) => ({
        type: "USER/SET_MESSAGES_PAGE_INFO",
        info
    }),
    setUsers: (users) => ({
        type: "USER/SET_USERS",
        users
    })
}

export const thunks = {
    setProfileUser: (userId) => async (dispatch, getState) => {
      let r = UserAPI.getUser(userId);

      if (r.response == "error") {
          dispatch(actions.setGetUserError(r.data.reason));
          dispatch(actions.setGetUserError(null));
      }
        else {
            dispatch(actions.setProfileUser(r.data.user));
      }
    },
    updateUser: (params) => async (dispatch, geState) => {
      let r = UserAPI.updateUser(params);

      dispatch(appActions.setUser(r.data.user));
      dispatch(appThunks.getTheme());
    },
    flagMessagesAsRead: (senderId, receiverId) => async (dispatch, getState) => {
        let r = UserAPI.flagMessagesAsRead(senderId, receiverId);
    },
    getMessages: (senderId, receiverId) => async (dispatch, getState) => {
        let r = UserAPI.getMessages(senderId, receiverId);

        dispatch(actions.setMessages(r.data.messages, r.data.user));
    },
    sendMessage: (senderId, receiverId, text, attachments) => async (dispatch, getState) => {
        let r = UserAPI.sendMessage(senderId, receiverId, text, attachments);

        dispatch(thunks.getMessages(senderId, receiverId));
    },
    isFriendTo: (userId, friendId) => async (dispatch, getState) => {
        let r = UserAPI.isFriendTo(userId, friendId);

        dispatch(actions.setIsFriends(r.data.isFriends));
    },
    getUser: (userId, whenAuthorizing) => async (dispatch, getState) => {
        let r = UserAPI.getUser(userId);

        if (whenAuthorizing) {
            dispatch(appActions.setUser(r.data.user))
            dispatch(appActions.toggleAuthorized())
        }
    },
    getUsers: (userId) => async (dispatch, getState) => {
      let r = UserAPI.getUsers(userId);

      dispatch(actions.setUsers(r.data.users));
    },
    getInfoForMessagesPage: (userId) => async (dispatch, getState) => {
        let r = UserAPI.getInfoForMessagesPage(userId)

        dispatch(actions.setMessagesPageInfo(r.data.info));
    },
    getAmountOfUnreadMessages: (userId) => async (dispatch, getState) => {
        let r = UserAPI.getAmountOfUnreadMessages(userId);

        dispatch(actions.setAmountOfUnreadMessages(r.data.amount));
    },
    getFriends: (userId) => async (dispatch, getState) => {
        let friends = UserAPI.getFriends(userId);

        dispatch(actions.setFriends(friends.data.friends));
    },
    deleteFriend: (userId) => async (dispatch, getState) => {
        let r = UserAPI.deleteFriend(userId);
        dispatch(actions.setIsFriends(false));
    },
    addFriend: (userId, friendId) => async (dispatch, getState) => {
        let r = UserAPI.addFriend(userId, friendId);
        dispatch(actions.setIsFriends(true));
    },
    setBasicInfoToStorage: (userId) => async (dispatch, getState) => {
        let r = UserAPI.setBasicInfoToStorage(userId);
    },
    authME: () => async (dispatch, getState) => {
        let r = UserAPI.getBasicInfoFromStorage();

        if (r.data.isAlreadyAuthorized && r.data.userId)
            dispatch(thunks.getUser(r.data.userId, true))
    },
    auth: (login, password) => async (dispatch, getState) => {
        let r = UserAPI.auth(login, password);

        if (r.response == "error")
            dispatch(actions.setAuthorizationError(r.data.reason))
        else {
            dispatch(appActions.setUser(r.data.user));
            dispatch(appActions.toggleAuthorized());
            dispatch(thunks.setBasicInfoToStorage(r.data.user.id));
        }
    },
    registerUser: (user) => async (dispatch, getState) => {
        let r = UserAPI.addUser(user);

        if (r.response == "error")
            dispatch(actions.setRegistrationError(r.data.reason));
        else {
            dispatch(appActions.toggleAuthorized());
            dispatch(appActions.setUser(r.data.user));
            dispatch(thunks.setBasicInfoToStorage(r.data.user.id))
        }
    },
    sighOut: () => async (dispatch, getState) => {
        let r = UserAPI.flushBasicInfo();

        dispatch(appActions.toggleAuthorized());
        dispatch(appActions.setUser(null));
    }
}

export default userReducer;
