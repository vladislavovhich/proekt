import UserAPI from "../../API/UserAPI";

let initState = {
    isMenuHidden: true,
    user: null,
    isAuthorized: false,
    isAuthorizing: false,
    theme: "Light"
}

const appReducer = (state = initState, action) => {
    switch (action.type) {
        case "APP/TOGGLE_MENU":
            return {
                ...state,
                isMenuHidden: !state.isMenuHidden
            }
        break;
        case "APP/TOGGLE_AUTHORIZED":
            return {
                ...state,
                isAuthorized: !state.isAuthorized
            }
        break;
        case "APP/SET_USER":
            return {
                ...state,
                user: {...action.user}
            }
        break;
        case "APP/SET_THEME":
            return {
                ...state,
                theme: action.value
            }
            break;
        default: 
            return state;
    }
}

export const actions = {
    setTheme: (value) => ({
        type: "APP/SET_THEME",
        value
    }),
    toggleMenu: () => ({
        type: "APP/TOGGLE_MENU"
    }),
    toggleAuthorized: () => ({
        type: "APP/TOGGLE_AUTHORIZED"
    }),
    setUser: (user) => ({
      type: "APP/SET_USER",
      user: user
    })
}
export const thunks = {
    getTheme: () => async (dispatch, getState) => {
        let theme = UserAPI.getTheme().data.theme;

        dispatch(actions.setTheme(theme));
    }
}

export default appReducer;

