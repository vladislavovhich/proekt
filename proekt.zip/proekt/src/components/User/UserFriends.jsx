import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import {thunks} from "../../store/reducers/userReducer";
import {useParams} from "react-router-dom";
import UserInfo from "./UserInfo";

const UserFriends = (props) => {
    let friends = useSelector(state => state.user.friends);
    let user = useSelector(state => state.app.user);

    const dispatch = useDispatch();
    const {id} = useParams();

    useEffect(() => {
        if (props.isOwnerProfile && props.isAuthorized)
            dispatch(thunks.getFriends(user.id));
        else
            dispatch(thunks.getFriends(id))
    }, [user]);

    return (
        <div className="UserFriends">
            {
                !friends.length ? <p>Список друзей пуст!</p> : friends.map((friend, ind) =>
                    <div className="GrayBlock py-2 px-3 mt-3" key={ind}>
                        <UserInfo
                            isOwnerProfile={props.isOwnerProfile}
                            isProfilePage={true}
                            name={friend.name}
                            surname={friend.surname}
                            shortName={friend.shortName}
                            date={friend.date}
                            avatar={friend.avatar}
                            id={friend.id}
                            isFriendsPage={true}
                        />
                    </div>)
            }
        </div>
    )
}

export default UserFriends