import React from "react";
import avatar from "../../images/avatar__standard.png"
import "../../styles/Common/UserInfo.scss"
import {Link} from "react-router-dom";

const UserInfo = (props) => {
   let textClass = props.isProfilePage ? "UserInfo__text__dark" : "UserInfo__text__light";

    return (
        <div className="UserInfo d-flex flex-row py-3 align-items-center">
            <img src={props.avatar || avatar} alt="user__avatar.png" className="UserInfo__avatar"/>

            <div className="d-flex flex-column ms-3 justify-content-center">
                <div className={textClass}>
                    {props.isProfilePage && "Имя: "}
                    {props.isFriendsPage ? <Link to={`/profile/${props.id}`}>{props.name + " " + props.surname}</Link> : props.name + " " + props.surname}
                </div>
                <div className="d-flex flex-column">
                    <div className={textClass}>
                        {props.isProfilePage && "Короткое имя: "}
                        @{props.shortName}
                    </div>
                    {props.isProfilePage && <div className={textClass}>{"Дата рождения: " + props.date}</div>}
                </div>
            </div>
        </div>
    )
}

export default UserInfo