import React, {useEffect, useRef, useState} from "react";
import {useParams} from "react-router-dom";
import {useDispatch, useSelector} from "react-redux";
import {thunks} from "../../store/reducers/userReducer";
import MessageTop from "./MessageTop";
import "../../styles/Common/UserMessagePage.scss"
import Message from "./Message";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faPlus, faArrowRight, faImage, faXmark} from "@fortawesome/free-solid-svg-icons";

const UserMessagePage = (props) => {
    const {id} = useParams();
    const appUser = useSelector(state => state.app.user);
    const messageUser = useSelector(state => state.user.messageUser);
    const messages = useSelector(state => state.user.messages);
    const dispatch = useDispatch();
    const attachmentsRef = useRef(null);
    const userMessageRef = useRef(null);
    const [messageText, setMessageText] = useState("");
    const [attachments, setAttachments] = useState([]);
    const [attachments64, setAttachments64] = useState([]);

    const messageFieldOnChange = (e) => {
        setMessageText(e.target.value);
    }
    const sendMessageOnClick = (e) => {
        if (!messageText && !attachments.length)
            return;

        setMessageText("");
        setAttachments([]);
        setAttachments64([]);

        dispatch(thunks.sendMessage(appUser.id, +id, messageText, attachments64));
    }
    const onFocusReadMessage = (e) => {
        dispatch(thunks.flagMessagesAsRead(appUser.id, +id));
    }
    const addAttachmentOnClick = (e) => {
        attachmentsRef.current.click();
    }
    const attachmentsInputOnChange = (e) => {
        if (!e.currentTarget.files.length)
            return;

        setAttachments([...attachments, ...e.currentTarget.files])

        let reader = new FileReader();

        reader.onloadend = () => setAttachments64([...attachments64, reader.result])
        reader.readAsDataURL(e.currentTarget.files[0]);
    }
    const deleteAttachment = (ind) => {
        if (!attachments.length)
            return;

        setAttachments(attachments.filter((attachment, i) => i != ind));
        setAttachments64(attachments64.filter((attachment, i) => i != ind));
    }

    useEffect(() => {
        dispatch(thunks.getMessages(appUser.id, +id));
    }, []);
    useEffect(() => {
        userMessageRef.current.scrollTop = userMessageRef.current.scrollHeight;
    });

    return (
        <div className="UserMessagePage">
            {
                messageUser &&
                <MessageTop
                    name={messageUser.name}
                    surname={messageUser.surname}
                    userId={messageUser.id}
                    avatar={messageUser.avatar}
                />
            }
            <div className="UserMessagePage__messages GrayBlock d-flex flex-column py-3 px-3 pb-3 my-3" ref={userMessageRef}>
                {!!messages.length ?
                    messages.map((message, ind) => {
                        return (
                            <Message
                                text={message.text}
                                attachments={message.attachments}
                                isReceiver={message.receiverId == appUser.id}
                                data={message.data}
                                isRead={message.isRead}
                                key={ind}
                           />
                    )}) : "Сообщений нет!"}
            </div>
            <div className="UserMessage__input d-flex flex-row justify-content-between">
                <button onClick={addAttachmentOnClick}>
                    <FontAwesomeIcon icon={faPlus} />
                    <input type="file" name="attachment" multiple ref={attachmentsRef} hidden accept="image/*" onChange={attachmentsInputOnChange}/>
                </button>
                <input
                    type="text"
                    placeholder="Введите текст сообщения"
                    value={messageText}
                    onChange={messageFieldOnChange}
                    onFocus={onFocusReadMessage}
                    className="flex-grow-1 mx-3"
                />
                <button onClick={sendMessageOnClick}>
                    <FontAwesomeIcon icon={faArrowRight} />
                </button>
            </div>
            {!!attachments.length &&
                <div className="UserMessagePage__attachments mt-3">
                    {attachments.map((attachment, ind) =>
                        <div key={ind} className="Message__attachment ps-3 py-1 pe-2 d-flex flex-row align-items-center justify-content-between">
                            <FontAwesomeIcon icon={faImage} />
                            <div className="Message__attachment__name ms-2">{attachment.name}</div>
                            <button className="Message__attachment__cancelBtn ms-2" onClick={() => deleteAttachment(ind)}>
                                <FontAwesomeIcon icon={faXmark}/>
                            </button>
                        </div>
                    )}
                </div>
            }
        </div>
    )
}

export default UserMessagePage