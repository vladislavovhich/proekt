import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import {thunks} from "../../store/reducers/userReducer";
import UserMessageBlock from "./UserMessageBlock";
import "../../styles/Common/UserMessagesPage.scss"

const UserMessagesPage = (props) => {
    const dispatch = useDispatch();
    const appUser = useSelector(store => store.app.user);
    const messagesInfo = useSelector(store => store.user.messagesPageInfo);

    useEffect(() => {
        dispatch(thunks.getInfoForMessagesPage(appUser.id));
    }, [appUser]);

    return (
        <div className="UserMessagesPage">
            {messagesInfo ? messagesInfo.map((messageInfo, ind) => {
                    return (
                        <UserMessageBlock
                            lastMessage={messageInfo.lastMessage}
                            user={messageInfo.user}
                            amountOfUnreadMessage={messageInfo.amountOfUnreadMessages}
                            isMyMessage={messageInfo.user.id == appUser.id}
                            key={ind}
                        />
                    )
                }) : "Нет сообщений"}
        </div>
    )
}

export default UserMessagesPage