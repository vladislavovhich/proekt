import React, {useRef, useState} from "react";
import Field from "../Login/Field";
import {faLock, faUserPen, faCalendarDays} from "@fortawesome/free-solid-svg-icons";
import {useForm} from "react-hook-form";
import * as yup from "yup";
import {yupResolver} from "@hookform/resolvers/yup";
import {useDispatch, useSelector} from "react-redux";
import {thunks} from "../../store/reducers/userReducer";
import {Navigate, useNavigate} from "react-router-dom";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faDownload} from "@fortawesome/free-solid-svg-icons";

const schema = yup.object({
    password: yup.string().required("Вы не ввели пароль!").min(5, "Минимум 5 символов").max(15, "Максимум 15 символов!"),
    name: yup.string().min(2, "Минумум 2 буквы!").max(15, "Максимум 15 букв!"),
    surname: yup.string().min(2, "Минумум 2 буквы!").max(15, "Максимум 15 букв!"),
    shortName: yup.string().min(2, "Минумум 2 буквы!").max(15, "Максимум 15 букв!"),
    date: yup.string().required("Вы не указали дату!")
}).required();

const Settings = (props) => {
    const appUser = useSelector(state => state.app.user);
    const t = useSelector(state => state.app.theme);
    const { register, handleSubmit, formState: {errors}, getValues } = useForm({
        resolver: yupResolver(schema),
        defaultValues: {
            password: appUser.password,
            name: appUser.name,
            surname: appUser.surname,
            date: appUser.date,
            shortName: appUser.shortName
        }
    });
    const [userAvatar, setUserAvatar] = useState(null);
    const [selectingFile, toggleSelectingFile] = useState(null);
    const [theme, setTheme] = useState(t)
    const fileFieldRef = useRef(null);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const themeOnChange = (e) => {
        setTheme(e.currentTarget.value);
        toggleSelectingFile(true);
    }
    const onSubmit = (e) => {
        const values = getValues();


        if (userAvatar) {
            let reader = new FileReader();

            reader.readAsDataURL(userAvatar);

            reader.onloadend = () => {
                dispatch(thunks.updateUser({id: appUser.id, ...values, avatar: reader.result, theme}));
                navigate("/profile");
            }
        } else {
            if (selectingFile == true || selectingFile != null) {
                dispatch(thunks.updateUser({id: appUser.id, ...values, avatar: null, theme}));
                navigate("/profile");
            }
        }
    }
    const onClickActiveFileField = () => {
        fileFieldRef.current.click();
    }
    const onChangeFileField = (e) => {
        if (!e.currentTarget.files.length)
            return;

        setUserAvatar(e.currentTarget.files[0]);
    }

    return (
        <div className="LoginPage d-flex flex-column align-items-center justify-content-center">
            <form onSubmit={handleSubmit(onSubmit)} className="LoginPage__form w-100 d-flex flex-column align-items-center">
                <Field
                    type="text"
                    placeholder="Имя"
                    name="name"
                    icon={faUserPen}
                    hookFormProps={register("name")}
                    error={errors.name}
                />

                <Field
                    type="text"
                    placeholder="Фамилия"
                    name="surname"
                    icon={faUserPen}
                    hookFormProps={register("surname")}
                    error={errors.surname}
                />

                <Field
                    type="text"
                    placeholder="Короткое имя"
                    name="shortName"
                    icon={faUserPen}
                    hookFormProps={register("shortName")}
                    error={errors.shortName}
                />

                <Field
                    type="date"
                    placeholder="Дата"
                    name="date"
                    icon={faCalendarDays}
                    hookFormProps={register("date")}
                    error={errors.date}
                />

                <Field
                    type="text"
                    placeholder="Пароль"
                    name="password"
                    icon={faLock}
                    hookFormProps={register("password")}
                    error={errors.password}
                />

                <input type="file" name="avatar" accept="image/*" hidden ref={fileFieldRef} onChange={onChangeFileField}/>
                <button className="Field__submitBtn" onClick={onClickActiveFileField}>
                    <FontAwesomeIcon icon={faDownload} className="Field__icon me-2"/>
                    Аватар
                </button>

                <div className="form-check mt-2">
                    <input className="form-check-input" type="radio" name="theme" id="radio" value="Light" checked={t == "Light" || theme == "Light"} onChange={themeOnChange}/>
                    <label className="form-check-label regularText" htmlFor="radio">
                        Светлая
                    </label>
                </div>
                <div className="form-check">
                    <input className="form-check-input" type="radio" name="theme" id="radio2" value="Dark" checked={t == "Dark" || theme == "Dark"} onChange={themeOnChange}/>
                    <label className="form-check-label regularText" htmlFor="radio2">
                        Темная
                    </label>
                </div>

                <input type="submit" value="Сохранить" className="Field__submitBtn"/>
            </form>
        </div>
    )
}

export default Settings