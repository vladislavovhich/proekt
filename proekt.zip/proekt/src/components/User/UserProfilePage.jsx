import React, {useEffect} from "react";
import UserInfo from "./UserInfo";
import "../../styles/Common/UserProfilePage.scss"
import {useDispatch, useSelector} from 'react-redux'
import MenuNavLink from "../SiteStructure/MenuNavLink";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons/faEnvelope";
import { faCog, faUserGroup, faUsers, faUserPlus, faUserMinus } from "@fortawesome/free-solid-svg-icons";
import {Navigate, useNavigate, useParams} from "react-router-dom";
import {thunks, actions} from "../../store/reducers/userReducer";

const UserProfilePage = (props) => {
    let user = useSelector(store => store.app.user);
    let appUser = useSelector(store => store.app.user);
    let profileUser = useSelector(store => store.user.profileUser);
    let getUserError = useSelector(store => store.user.getUserError);
    let isFriends = useSelector(store => store.user.isFriends);
    let friendsLength = useSelector(store => store.user.friends.length);
    let amountOfUnreadMessages = useSelector(store => store.user.amountOfUnreadMessages);

    const dispatch = useDispatch();
    const {id} = useParams();

    const addFriend = (e) => {
        dispatch(thunks.addFriend(appUser.id, profileUser.id));
    }
    const deleteFriend = (e) => {
        dispatch(thunks.deleteFriend(appUser.id));
    }

    useEffect(() => {
        dispatch(thunks.setProfileUser(+id));
    }, [id]);
    useEffect(() => {
        if (props.isAuthorized && !props.isOwnerProfile && appUser && profileUser) {
            dispatch(thunks.isFriendTo(appUser.id, profileUser.id));
        }
    }, [appUser])
    useEffect(() => {
        if (user) {
            dispatch(thunks.getFriends(user.id));
            dispatch(thunks.getAmountOfUnreadMessages(user.id));
        }
    }, [user]);
    
    if (id && appUser != null && appUser.id == id)
        return <Navigate replace to="/profile"/>

    if (!props.isOwnerProfile && getUserError)
        return <p>{getUserError}</p>
    
    if (!props.isOwnerProfile && profileUser) {
        user = profileUser
    }

    return (
        <div className="UserProfilePage d-flex flex-column">
            <div className="UserProfilePage__block px-3 py-2">
                {user &&
                    <UserInfo
                        isOwnerProfile={props.isOwnerProfile}
                        isProfilePage={true}
                        name={user.name}
                        surname={user.surname}
                        shortName={user.shortName}
                        date={user.date}
                        avatar={user.avatar}
                    />
                }
            </div>
            <div className="UserProfilePage__block mt-2 px-3 py-2">
                <nav className="UserProfilePage__nav">
                    <ul className="Menu__links d-flex flex-row justify-content-between">
                        {props.isOwnerProfile &&
                            <li  className="d-flex flex-row align-items-center">
                                <MenuNavLink
                                    icon={faEnvelope}
                                    path="/messages"
                                    text="Сообщения"
                                />
                                <div className="Circle mt-1 ms-1">{amountOfUnreadMessages}</div>
                            </li>
                        }
                        <li className="d-flex flex-row align-items-center">
                            <MenuNavLink
                                icon={faUserGroup}
                                path="/groups"
                                text="Группы"
                            />
                            <div className="Circle mt-1 ms-1">0</div>
                        </li>
                        <li className="d-flex flex-row align-items-center">
                            <MenuNavLink
                                icon={faUsers}
                                path={!props.isOwnerProfile && user ? `/friends/${user.id}` : "/friends"}
                                text="Друзья"
                            />
                            <div className="Circle mt-1 ms-1">{friendsLength}</div>
                        </li>
                        {!props.isOwnerProfile && props.isAuthorized && profileUser &&
                            <MenuNavLink
                                icon={faEnvelope}
                                text="Написать"
                                path={`/messages/${profileUser.id}`}
                            />
                        }
                        {!props.isOwnerProfile && props.isAuthorized &&
                            <MenuNavLink
                                icon={isFriends ? faUserMinus : faUserPlus}
                                handler={isFriends ? deleteFriend : addFriend}
                                text={isFriends ? "Удалить" : "Добавить"}
                            />
                        }
                        {props.isOwnerProfile &&
                            <li>
                                <MenuNavLink
                                    icon={faCog}
                                    path="/settings"
                                    text="Настройки"
                                />
                            </li>
                        }
                    </ul>
                </nav>
            </div>
        </div>
    )
}

export default UserProfilePage