import React from "react";
import avatar from "../../images/avatar__standard.png";
import MenuNavLink from "../SiteStructure/MenuNavLink";
import {faArrowRight} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {Link} from "react-router-dom";

const UserMessageBlock = (props) => {
    return (
        <div className="UserMessageBlock d-flex flex-row align-items-center GrayBlock px-3 py-2">
            <div>
                <img src={props.user.avatar || avatar} alt="" className="UserMessageBlock__avatar"/>
            </div>
            <div className="ms-2 d-flex flex-column w-100">
                <div className="d-flex flex-row justify-content-between">
                    <div className="ms-1 d-flex flex-row align-items-center">
                        {props.isMyMessage ? "Вы" : `${props.user.name} ${props.user.surname}`}
                        {!!props.amountOfUnreadMessage &&
                            <div className="Circle ms-1 mb-1">
                                {props.amountOfUnreadMessage}
                            </div>
                        }
                    </div>
                    <div>{new Date(props.lastMessage.data).toLocaleTimeString().substring(0, 5)}</div>
                </div>
                <div className="mt-1 d-flex flex-row w-100 align-items-center">
                    <div className="UserMessageBlock__text px-2 py-1 flex-grow-1">
                        {props.lastMessage.text || "Изображение..."}
                    </div>
                    <Link to={`/messages/${props.user.id}`} className="pe-2 LightLink d-flex flex-row align-items-center">
                        <FontAwesomeIcon icon={faArrowRight} className="LightLink__icon"/>
                    </Link>
                </div>
            </div>
        </div>
    )
}

export default UserMessageBlock