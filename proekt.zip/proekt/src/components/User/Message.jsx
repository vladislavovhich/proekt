import React from "react";
import {faCheck, faCheckDouble} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const Message = (props) => {
    let data = new Date(props.data);

    return (
        <div className={`Message ${props.isReceiver ? "Message__receiver" : "Message__sender"} px-3 py-1 ${props.isReceiver ? "align-self-start" : "align-self-end"}`}>
            <div className="text-align-justify Message__text">
                {props.text}
            </div>
            {!!props.attachments.length &&
                <div className="Message__attachments mt-2 mb-1">
                    {props.attachments.map((attachment, ind) => <img key={ind} src={attachment} className="img-fluid"/>)}
                </div>
            }
            <div className={`d-flex flex-row align-items-center w-100 ${!props.isReceiver ? "justify-content-end" : "justify-content-start"}`}>
                {data.toLocaleTimeString().substring(0, 5)}
                <FontAwesomeIcon icon={props.isRead ? faCheckDouble : faCheck} className="ms-2"/>
            </div>
        </div>
    )
}

export default Message