import React, {useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import {thunks} from "../../store/reducers/userReducer";
import {useParams} from "react-router-dom";
import UserInfo from "./UserInfo";

const Users = (props) => {
    let users = useSelector(state => state.user.users);
    let user = useSelector(state => state.app.user);

    const dispatch = useDispatch();

    useEffect(() => {
        if (user)
            dispatch(thunks.getUsers(user.id));
        else
            dispatch(thunks.getUsers());
    }, [user]);

    return (
        <div className="UserFriends">
            {
                !users.length ? <p>Пользователей нет</p> : users.map((user, ind) =>
                    <div className="GrayBlock py-2 px-3 mt-3" key={ind}>
                        <UserInfo
                            isOwnerProfile={props.isOwnerProfile}
                            isProfilePage={true}
                            name={user.name}
                            surname={user.surname}
                            shortName={user.shortName}
                            date={user.date}
                            avatar={user.avatar}
                            id={user.id}
                            isFriendsPage={true}
                        />
                    </div>)
            }
        </div>
    )
}

export default Users