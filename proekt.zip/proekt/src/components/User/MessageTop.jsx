import React from "react";
import avatar from "../../images/avatar__standard.png";
import {faAngleLeft} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {Link} from "react-router-dom";

const MessageTop = (props) => {

    return (
        <div className="MessageTop GrayBlock d-flex flex-row justify-content-between align-items-center px-2 py-2">
            <Link to="/messages" className="LightLink">
                <FontAwesomeIcon icon={faAngleLeft} className="LightLink__icon"/>
            </Link>

            <Link to={`/profile/${props.userId}`} className="LightLink">
                {props.name + " " + props.surname}
            </Link>

            <img src={props.avatar || avatar} alt="avatar.png" className="MessageTop__avatar me-1"/>
        </div>
    )
}

export default MessageTop