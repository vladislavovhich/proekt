import { useSelector, useDispatch } from 'react-redux'
import {actions} from "../store/reducers/appReducer"
import {thunks} from "../store/reducers/userReducer";
import React, {useEffect} from "react";
import Header from "./SiteStructure/Header"
import Menu from "./SiteStructure/Menu"
import Main from "./SiteStructure/Main"
import "../styles/Common/Light.scss"
import "../styles/Common/Dark.scss"
import "../styles/Common/Common.scss"
import {thunks as appThunks} from "../store/reducers/appReducer"

const App = () => {
    const isMenuHidden = useSelector((state) => state.app.isMenuHidden)
    const isAuthorized = useSelector((state) => state.app.isAuthorized)
    const theme = useSelector((state) => state.app.theme);
    const user = useSelector((state) => state.app.user)
    const dispatch = useDispatch()

    const toggleMenu = () => {
        dispatch(actions.toggleMenu())
    }
    const sighOut = () => {
        dispatch(thunks.sighOut());
    }

    useEffect(() => {
        dispatch(thunks.authME());
        dispatch(appThunks.getTheme())
    }, []);

    return (
        <div className={`App ${theme} d-flex flex-column flex-grow-1`}>
            <Header toggleMenu={toggleMenu}/>
            <Menu
                menuClass={isMenuHidden ? "Menu__hidden animate__bounceInLeft" : "Menu__visible animate__bounceInRight"}
                toggleMenu={toggleMenu}
                sighOut={sighOut}
                isAuthorized={isAuthorized}
                user={user}
            />
            <Main isAuthorized={isAuthorized}/>
        </div>
    )
}

export default App