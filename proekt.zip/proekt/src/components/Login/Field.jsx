import React from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";

const Field = (props) => {

    return (
        <div className="Field d-flex flex-column align-items-center">
            <div className="Field__inputBox d-flex flex-row align-items-center">
                {<FontAwesomeIcon icon={props.icon} className="Field__icon" onClick={props.iconHandler}/>}
                <input type={props.type} name={props.name} placeholder={props.placeholder} className="Field__input" {...props.hookFormProps}/>
            </div>
            {props.error && <div className="Field__error mt-1">{props.error.message}</div>}
        </div>
    )
}

export default Field