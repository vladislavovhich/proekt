import React, {useState} from "react";
import { useForm } from "react-hook-form";
import {faUser, faEyeSlash, faEye} from "@fortawesome/free-solid-svg-icons";
import Field from "./Field";
import "../../styles/Common/LoginPage.scss"
import {Link, useNavigate} from "react-router-dom";
import * as yup from "yup";
import {yupResolver} from "@hookform/resolvers/yup";
import {useDispatch, useSelector} from 'react-redux'
import {thunks} from "../../store/reducers/userReducer";

const schema = yup.object({
    login: yup.string().required("Вы не ввели почту!").email("Вы неправильно ввели почту!"),
    password: yup.string().required("Вы не ввели пароль!").min(5, "Минимум 5 символов").max(15, "Максимум 15 символов!")
}).required();

const LoginPage = (props) => {
    const { register, handleSubmit, formState: {errors}, getValues } = useForm({
        resolver: yupResolver(schema)
    });
    const dispatch = useDispatch();
    const [isVisible, toggleIsVisible] = useState(false);
    const authError = useSelector(state => state.user.authorizationError);
    const navigate = useNavigate();
    const toggleIsVisibleOnClick = () => toggleIsVisible(!isVisible);

    const onSubmit = (e) => {
        const values = getValues();

        dispatch(thunks.auth(values.login, values.password));
    }

    if (props.isAuthorized)
        navigate("/profile")

    return (
        <div className="LoginPage d-flex flex-column align-items-center justify-content-center">
            <form onSubmit={handleSubmit(onSubmit)} className="LoginPage__form w-100 d-flex flex-column align-items-center">
                <Field
                    type="text"
                    placeholder="Логин"
                    name="login"
                    icon={faUser}
                    hookFormProps={register("login")}
                    error={errors.login}
                />

                <Field
                    type={isVisible ? "text" : "password"}
                    placeholder="Пароль" name="password"
                    icon={isVisible ? faEye : faEyeSlash}
                    iconHandler={toggleIsVisibleOnClick}
                    hookFormProps={register("password")}
                    error={errors.password}
                />

                {authError && <p>{authError}</p>}

                <Link to="/registration" className="LightLink d-flex flex-row align-items-center justify-content-center">
                    Нет аккаунта?
                </Link>

                <input type="submit" value="Войти" className="Field__submitBtn"/>
            </form>
        </div>
    )
}

export default LoginPage