import React from "react";
import Field from "./Field";
import {faUser, faLock, faUserPen, faCalendarDays} from "@fortawesome/free-solid-svg-icons";
import {useForm} from "react-hook-form";
import * as yup from "yup";
import {yupResolver} from "@hookform/resolvers/yup";
import {useDispatch, useSelector} from "react-redux";
import {thunks} from "../../store/reducers/userReducer";
import {Navigate} from "react-router-dom";

const schema = yup.object({
    login: yup.string().required("Вы не ввели почту!").email("Вы неправильно ввели почту!"),
    password: yup.string().required("Вы не ввели пароль!").min(5, "Минимум 5 символов").max(15, "Максимум 15 символов!"),
    name: yup.string().min(2, "Минумум 2 буквы!").max(15, "Максимум 15 букв!"),
    surname: yup.string().min(2, "Минумум 2 буквы!").max(15, "Максимум 15 букв!"),
    shortName: yup.string().min(2, "Минумум 2 буквы!").max(15, "Максимум 15 букв!"),
    date: yup.string().required("Вы не указали дату!")
}).required();

const RegistrationPage = (props) => {
    const { register, handleSubmit, formState: {errors}, getValues } = useForm({
        resolver: yupResolver(schema)
    });
    const dispatch = useDispatch();
    const registrationError = useSelector(state => state.user.registrationError);
    const isRegistrating = useSelector(state => state.app.isRegistrating);

    const onSubmit = (e) => {
        const values = getValues();

        dispatch(thunks.registerUser(values));
    }

    return (
        <div className="LoginPage d-flex flex-column align-items-center justify-content-center">
            <form onSubmit={handleSubmit(onSubmit)} className="LoginPage__form w-100 d-flex flex-column align-items-center">
                <Field
                    type="text"
                    placeholder="Логин"
                    name="login"
                    icon={faUser}
                    hookFormProps={register("login")}
                    error={errors.login}
                />

                <Field
                    type="text"
                    placeholder="Пароль"
                    name="password"
                    icon={faLock}
                    hookFormProps={register("password")}
                    error={errors.password}
                />

                <Field
                    type="text"
                    placeholder="Имя"
                    name="name"
                    icon={faUserPen}
                    hookFormProps={register("name")}
                    error={errors.name}
                />

                <Field
                    type="text"
                    placeholder="Фамилия"
                    name="surname"
                    icon={faUserPen}
                    hookFormProps={register("surname")}
                    error={errors.surname}
                />

                <Field
                    type="text"
                    placeholder="Короткое имя"
                    name="shortName"
                    icon={faUserPen}
                    hookFormProps={register("shortName")}
                    error={errors.shortName}
                />

                <Field
                    type="date"
                    placeholder="Дата"
                    name="date"
                    icon={faCalendarDays}
                    hookFormProps={register("date")}
                    error={errors.date}
                />

                {registrationError && <p>{registrationError}</p>}

                <input type="submit" value="Создать" className="Field__submitBtn" disabled={isRegistrating}/>
            </form>
        </div>
    )
}

export default RegistrationPage