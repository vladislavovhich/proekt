import React from "react";
import "../../styles/Common/Menu.scss"
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {faAngleRight} from '@fortawesome/free-solid-svg-icons/faAngleRight'
import UserInfo from "../User/UserInfo";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons/faEnvelope";
import { faCog, faUser, faUserGroup, faUsers, faRightFromBracket , faDoorOpen, faUsersLine} from "@fortawesome/free-solid-svg-icons";
import MenuNavLink from "./MenuNavLink";
import {useNavigate} from "react-router-dom";

const Menu = (props) => {
    const navigate = useNavigate()

    return (
        <nav className={`Menu ${props.menuClass} w-50 h-100`}>
                <div className="d-flex flex-column">
                    <div className="Menu__userDescription px-3 py-2">
                        <div className="Menu__userDescription__top d-flex flex-row justify-content-between">
                            <FontAwesomeIcon
                                icon={faAngleRight}
                                className="Link"
                                onClick={props.toggleMenu}
                            />

                                <FontAwesomeIcon
                                    icon={props.isAuthorized ? faRightFromBracket: faDoorOpen}
                                    className="Link"
                                    onClick={props.isAuthorized ?
                                        () => {
                                            navigate("/login");
                                            props.sighOut();
                                            props.toggleMenu();
                                        } : () => {
                                            navigate("/login");
                                            props.toggleMenu();
                                        }
                                    }
                                />
                        </div>
                        {props.isAuthorized &&
                            <div className="Menu__userDescription__mid">
                                <UserInfo
                                    name={props.user.name}
                                    surname={props.user.surname}
                                    shortName={props.user.shortName}
                                    avatar={props.user.avatar}
                                />
                            </div>
                        }
                    </div>
                </div>
            <ul className="Menu__links px-3 py-2 d-flex flex-column">
                <li>
                    <MenuNavLink
                        icon={faUser}
                        path="/profile"
                        text="Профиль"
                        handler={props.toggleMenu}
                    />
                </li>
                <li>
                    <MenuNavLink
                        icon={faUsers}
                        path="/friends"
                        text="Друзья"
                        handler={props.toggleMenu}
                    />
                </li>
                <li>
                    <MenuNavLink
                        icon={faEnvelope}
                        path="/messages"
                        text="Сообщения"
                        handler={props.toggleMenu}
                    />
                </li>
                <li>
                    <MenuNavLink
                        icon={faUserGroup}
                        path="/groups"
                        text="Группы"
                        handler={props.toggleMenu}
                    />
                </li>
                <li>
                    <MenuNavLink
                        icon={faUsersLine}
                        path="/users"
                        text="Пользователи"
                        handler={props.toggleMenu}
                    />
                </li>
                <li>
                    <MenuNavLink
                        icon={faCog}
                        path="/settings"
                        text="Настройки"
                        handler={props.toggleMenu}
                    />
                </li>
            </ul>
        </nav>
    )
}

export default Menu