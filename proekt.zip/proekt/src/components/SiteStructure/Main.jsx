import {Route, Routes, Navigate} from "react-router-dom";
import React from "react";
import UserProfilePage from "../User/UserProfilePage";
import LoginPage from "../Login/LoginPage";
import RegistrationPage from "../Login/RegistrationPage";
import UserFriends from "../User/UserFriends";
import UserMessagePage from "../User/UserMessagePage";
import UserMessagesPage from "../User/UserMessagesPage";
import Settings from "../User/Settings";
import Users from "../User/Users";

const Main = (props) => {
    return (
        <main className="d-flex flex-column">
            <div className="container py-3 ">
                <Routes>
                    <Route exact path="/profile" element={props.isAuthorized ?  <UserProfilePage isAuthorized={props.isAuthorized} isOwnerProfile={true}/> : <Navigate replace to="/login" />}/>
                    <Route exact path="/friends" element={<UserFriends isOwnerProfile={true} isAuthorized={props.isAuthorized}/>}/>
                    <Route exact path="/friends/:id" element={<UserFriends isOwnerProfile={false}/>}/>
                    <Route exact path="/profile/:id" element={<UserProfilePage isAuthorized={props.isAuthorized} isOwnerProfile={false}/>}/>
                    <Route exact path="/login" element={!props.isAuthorized ? <LoginPage isAuthorized={props.isAuthorized} /> : <Navigate replace to="/profile" />} />
                    <Route exact path="/messages/:id" element={!props.isAuthorized ? <LoginPage /> : <UserMessagePage />} />
                    <Route exact path="/messages" element={!props.isAuthorized ? <LoginPage /> : <UserMessagesPage />} />
                    <Route exact path="/users" element={<Users isAuthorized={props.isAuthorized} />} />
                    <Route exact path="/registration" element={!props.isAuthorized ?  <RegistrationPage /> : <Navigate replace to="/profile" />} />
                    <Route exact path="/settings" element={!props.isAuthorized ?  <RegistrationPage /> : <Settings />} />
                </Routes>
            </div>
        </main>
    )
}

export default Main