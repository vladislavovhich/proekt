import React from "react";
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {faBars} from '@fortawesome/free-solid-svg-icons/faBars'
import logo from "../../images/logo.png"
import "../../styles/Common/Header.scss"

const Header = (props) => {
    return (
        <header className="Header w-100">
            <div className="h-100 container d-flex flex-row align-items-center justify-content-between">
                <img src={logo} alt="logo.png" className="Header__logo "/>
                <FontAwesomeIcon icon={faBars} className="Link" onClick={props.toggleMenu}/>
            </div>
        </header>
    )
}

export default Header;