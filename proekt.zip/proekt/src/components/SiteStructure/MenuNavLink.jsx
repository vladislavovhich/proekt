import React from "react";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {Link} from "react-router-dom";

const MenuNavLink = (props) => {

    if (!props.path)
        return (
            <a className="LightLink d-flex flex-row align-items-center" onClick={props.handler}>
                <FontAwesomeIcon icon={props.icon} className="LightLink__icon"/>
                <div className="LightLink__text">{props.text}</div>
            </a>
        )
    return (
        <Link to={props.path} className="LightLink d-flex flex-row align-items-center" onClick={props.handler}>
            <FontAwesomeIcon icon={props.icon} className="LightLink__icon"/>
            <div className="LightLink__text">{props.text}</div>
        </Link>
    )
}

export default MenuNavLink