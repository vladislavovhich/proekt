const UserAPI = {
    updateUser({avatar, id, name, surname, shortName, date, password, theme}) {
        if (!localStorage.users) {
            localStorage.users = JSON.stringify([]);
        }

        let users = JSON.parse(localStorage.users);
        let userIndex;

        users.forEach((user, index) => user.id == id && (userIndex = index));

        users[userIndex].name = name;
        users[userIndex].surname = surname;
        users[userIndex].shortName = shortName;
        users[userIndex].date = date;
        users[userIndex].password = password;
        users[userIndex].avatarId = avatar ? this.addImage(avatar).data.image.id : users[userIndex].avatarId;

        localStorage.theme = theme;
        localStorage.users = JSON.stringify(users);
        
        return {
            response: "ok",
            data: {
                user: {...users[userIndex], avatar:  users[userIndex].avatarId ?  this.getImage( users[userIndex].avatarId).data.image.value : users[userIndex].avatarId}
            }
        }
    },
    getTheme() {
      if (!localStorage.theme)
          localStorage.theme = "Light";

      return {
          response: "ok",
          data: {
              theme: localStorage.theme
          }
      }
    },
    auth(login, password) {
        if (!localStorage.users) {
            localStorage.users = JSON.stringify([]);
        }

        let users = JSON.parse(localStorage.users);
        let userIndex = -1;

        users.forEach((user, index) => user.login == login && (userIndex = index));

        if (userIndex == -1)
            return {
                response: "error",
                data: {
                    reason: "Такого пользователя нет"
                }
            }

        if (users[userIndex].password != password)
            return {
                response: "error",
                data: {
                    reason: "Пароли не совпадают!"
                }
            }

        return {
            response: "ok",
            data: {
                user: {...users[userIndex], avatar: users[userIndex].avatarId ?  this.getImage( users[userIndex].avatarId).data.image.value : users[userIndex].avatarId}
            }
        }
    },
    getUsers(userId) {
        if (!localStorage.users)
            localStorage.users = JSON.stringify([]);

        let users = JSON.parse(localStorage.users);

        if (userId)
            users = users.filter(user => user.id !== userId);

        return {
            response: "ok",
            data: {
                users: users.map(user => ({...user, avatar: user.avatarId ? this.getImage(user.avatarId).data.image.value : user.avatarId}))
            }
        }
    },
    setBasicInfoToStorage(userId) {
        if (!localStorage.isAlreadyAuthorized)
            localStorage.isAlreadyAuthorized = true;

        localStorage.currentUserId = userId;

        return {
            response: "ok"
        }
    },
    flushBasicInfo() {
      localStorage.isAlreadyAuthorized = "";
      localStorage.currentUserId = null;

      return {
          response: "ok"
      }
    },
    getBasicInfoFromStorage() {
        if (!localStorage.isAlreadyAuthorized)
            localStorage.isAlreadyAuthorized = false;

        return {
            response: "ok",
            data: {
                isAlreadyAuthorized: localStorage.isAlreadyAuthorized,
                userId: +localStorage.currentUserId
            }
        }
    },
    addFriend(userId, friendId) {
        if (!localStorage.friends)
            localStorage.friends = JSON.stringify([]);

        let friends = JSON.parse(localStorage.friends);

        friends.push({
            id: friends.length + 1,
            userId1: userId,
            userId2: friendId
        })

        localStorage.friends = JSON.stringify(friends);

        return {
            response: "ok"
        }
    },
    deleteFriend(userId) {
        if (!localStorage.friends)
            localStorage.friends = JSON.stringify([]);

        let friends = JSON.parse(localStorage.friends);
        let index = 0;

        friends.forEach((friend, i) => (friend.userId1 == userId || friend.userId2 == userId) && (index = i));

        friends = friends.filter((friend, ind) => ind != index);

        console.log(friends);

        localStorage.friends = JSON.stringify(friends);

        return {
            response: "ok"
        }
    },
    isFriendTo(userId, friendId) {
        if (!localStorage.friends)
            localStorage.friends = JSON.stringify([]);

        let friends = JSON.parse(localStorage.friends);
        let isFriends = false;

        friends.forEach(friend => ((friend.userId1 == userId && friend.userId2 == friendId) || (friend.userId2 == userId && friend.userId1 == friendId)) && (isFriends = true))

        return {
            response: "ok",
            data: {
                isFriends: isFriends
            }
        }
    },
    sendMessage(senderId, receiverId, text, attachments) {
        if (!localStorage.messages)
            localStorage.messages = JSON.stringify([]);

        let messages = JSON.parse(localStorage.messages);
        let attachmentsId = [];

        console.log(attachments);

        attachments.forEach(attachment => attachmentsId.push(this.addImage(attachment).data.image.id));

        let message = {
            id: messages.length + 1,
            senderId, receiverId, text,
            data: +new Date(),
            isRead: false,
            attachments: attachmentsId
        };

        messages.push(message);

        localStorage.messages = JSON.stringify(messages);

        return {
            response: "ok",
            data: {
                message
            }
        }
    },
    getMessages(senderId, receiverId) {
        if (!localStorage.messages)
            localStorage.messages = JSON.stringify([]);

        let messages = JSON.parse(localStorage.messages);
        let userMessages = [];
        let userMessageByDates = {};

        messages.forEach(message => ((message.senderId == senderId && message.receiverId == receiverId) || (message.senderId == receiverId && message.receiverId == senderId)) && userMessages.push(message));

        userMessages = userMessages.map(message => (
            {...message, attachments: message.attachments && message.attachments.map(attachment => this.getImage(attachment).data.image.value)}
        ))

        return {
            response: "ok",
            data: {
                messages: userMessages,
                user: this.getUser(receiverId).data.user
            }
        }
    },
    flagMessagesAsRead(senderId, receiverId) {
        if (!localStorage.messages)
            localStorage.messages = JSON.stringify([]);

            let messages = JSON.parse(localStorage.messages);
            let userMessages = [];
            let userMessageByDates = {};

            messages.forEach((message, index) => {
                if ((message.senderId == senderId && message.receiverId == receiverId) || (message.senderId == receiverId && message.receiverId == senderId)) {
                    if (message.receiverId == senderId) {
                        messages[index].isRead = true;
                        userMessages.push({...message, isRead: true})
                    } else
                        userMessages.push(message)
                }
            });

            localStorage.messages = JSON.stringify(messages);

            return {
                response: "ok",
                data: {
                    messages: userMessages,
                    user: this.getUser(receiverId).data.user
                }
            }
    },
    getInfoForMessagesPage(userId) {
        if (!localStorage.messages)
            localStorage.messages = JSON.stringify([]);

        let messages = JSON.parse(localStorage.messages);
        let resultMessages = [];
        let usersMessages = {};

        messages.forEach((message, index) => {
            if (message.receiverId == userId) {
                if (!usersMessages[message.senderId])
                    usersMessages[message.senderId] = {user: this.getUser(message.senderId).data.user, messages: []}

                usersMessages[message.senderId].messages.push(message);
            } else if (message.senderId == userId) {
                if (!usersMessages[message.receiverId])
                    usersMessages[message.receiverId] = {user: this.getUser(message.receiverId).data.user, messages: []}

                usersMessages[message.receiverId].messages.push(message);
            }
        });

        for (let prop in usersMessages) {
            let element = usersMessages[prop];
            resultMessages.push({lastMessage: element.messages[element.messages.length - 1], user: element.user, amountOfUnreadMessages: this.getAmountOfUnreadMessages(userId).data.amount});
        }

        return {
            response: "ok",
            data: {
                info: resultMessages
            }
        }
    },
    getAmountOfUnreadMessages(userId) {
        if (!localStorage.messages)
            localStorage.messages = JSON.stringify([]);

        let messages = JSON.parse(localStorage.messages);
        let userMessages = [];

        messages.forEach((message, index) => {
            if (message.receiverId == userId && !message.isRead) {
                userMessages.push(message)
            }
        });

        localStorage.messages = JSON.stringify(messages);

        return {
            response: "ok",
            data: {
                amount: userMessages.length
            }
        }
    },
    getFriends(userId) {
        if (!localStorage.friends)
            localStorage.friends = JSON.stringify([]);

        let friends = JSON.parse(localStorage.friends);
        let userFriends = [];

        friends.forEach(friend => {
            (friend.userId1 == userId || friend.userId2 == userId) && userFriends.push(this.getUser(friend.userId1 == userId ? friend.userId2 : friend.userId1).data.user)
        })

        return {
            response: "ok",
            data: {
                friends: userFriends
            }
        }
    },
    getUser(userId) {
        if (!localStorage.users) {
            localStorage.users = JSON.stringify([]);
        }
            
        let users = JSON.parse(localStorage.users);
        let userIndex = -1;
        
        users.forEach((user, index) => user.id == userId && (userIndex = index))

        if (userIndex == -1)
            return {
                response: "error",
                data: {
                    reason: "Такого пользователя нет!"
                }
            }

        return {
            response: "ok",
            data: {
                user: {...users[userIndex], avatar: users[userIndex].avatarId ? this.getImage(users[userIndex].avatarId).data.image.value : users[userIndex].avatarId}
            }
        }
    },
    addImage(value) {
        if (!localStorage.images) {
            localStorage.images = JSON.stringify([]);
        }
        
        let images = JSON.parse(localStorage.images);

        let image = {
            id: images.length + 1,
            value: value
        }
        
        images.push(image);
        
        localStorage.images = JSON.stringify(images);
        
        return {
            response: "ok",
            data: {
                image
            }
        };
    },
    getImage(id) {
      if (!localStorage.images)
          localStorage.images = JSON.stringify([]);

        let images = JSON.parse(localStorage.images);
        let image;

        images.forEach(img => img.id == id && (image = img));

        return {
            response: "ok",
            data: {
                image
            }
        }
    },
    addUser({name, surname, shortName, login, date, password}) {
        if (!localStorage.users) {
            localStorage.users = JSON.stringify([]);
        }

        let isThereUserWithSuchLogin = false;
        let users = JSON.parse(localStorage.users);

        for (let user of users)
            if (user.login == login)
                isThereUserWithSuchLogin = true;

        let user = {
            id: users.length + 1,
            name: name,
            surname: surname,
            shortName: shortName,
            password: password,
            login: login,
            date: date,
            avatarId: null
        };

        if (isThereUserWithSuchLogin)
            return {
                response: "error",
                data: {
                    reason: "Такой пользователь уже есть!"
                }
            }
        
        users.push(user);
        
        localStorage.users = JSON.stringify(users);
        
        return {
            response: "ok",
            data: {
                user: user
            }
        }
    }
}

export default UserAPI